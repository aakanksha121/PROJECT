package com.student.Student;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@RequestMapping("callapi")
	public String callapi() {
		
		return"callapi";
	}
	
	@RequestMapping("testcall")
	public ModelAndView test() {
		ArrayList<String> arraylist=new ArrayList<>();
		arraylist.add("Pranav");
		arraylist.add("Arbaj");
		arraylist.add("Akanksha");
		ModelAndView modelandview=new ModelAndView("test","data",arraylist);
		return modelandview;
		
	}

}
