package com.student.Student;

import java.util.Comparator;



public class sortonprice implements Comparator<Mobile> {

	@Override
	public int compare(Mobile mob1, Mobile mob2) {
		
		Integer price1=mob1.price;
		Integer price2=mob2.price;
		
		Integer speed1=mob1.speed;
		Integer speed2=mob2.speed;
		
		if(price1.equals(price2))
			return -speed1.compareTo(speed2);
		
		return price1.compareTo(price2);
	}
	
	
	

}
