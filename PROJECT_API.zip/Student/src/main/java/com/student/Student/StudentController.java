package com.student.Student;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {
	
@Autowired
SessionFactory factory;
    

	List<student> arraylist=null; 
	
	StudentController(){
		
		}
	
	@GetMapping("getallstudents")
	List<student> GetAllStudents() {
		Session s=factory.openSession();
		arraylist=s.createCriteria(student.class).list();
		return arraylist;	
	}
	
	@GetMapping("getstudent/{rno}")
	student GetStudent(@PathVariable int rno) {
		Session s=factory.openSession();
		student stu=s.load(student.class, rno);
		return stu;
		}
	
	@PostMapping("addstudent")
	List<student> AddStudent(@RequestBody student student) {
		Session s=factory.openSession();
		Transaction trans=s.beginTransaction();
		
		s.save(student);
		
		trans.commit();
		List<student> list=GetAllStudents();
		return list;
		}
	
	@DeleteMapping("deletestudent/{rno}")
	List<student> deleteStudent(@PathVariable int rno) {
		
		Session s=factory.openSession();
		student stu=s.load(student.class, rno);
		
		Transaction tx=s.beginTransaction();
		
		s.delete(stu);
		
		tx.commit();
		
		List<student> list=GetAllStudents();
		return list;
		
		
	  }
	
	@PutMapping("updatestudent")
	List<student> UpdateStudent(@RequestBody student stu) {
		
		Session s=factory.openSession();
		 Transaction tx=s.beginTransaction();
		 
		 s.saveOrUpdate(stu);
		 tx.commit();
		 List<student> list=GetAllStudents();
		 return list;
		}
	}
