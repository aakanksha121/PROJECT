package com.student.Student;

import java.util.List;
import java.util.TreeSet;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {
	
	@Autowired
	SessionFactory factory;
	
	@RequestMapping("getmobiles")
	public List<Mobile> GetMobiles(){
		
		//List<Mobile> arraylist=factory.openSession().createCriteria(Mobile.class).list();
		
		List<Mobile> arraylist=factory.openSession().createQuery("from Mobile").list();
		System.out.println(arraylist);
		
/*TreeSet<Mobile> treeset=new TreeSet<Mobile>(new sortonprice());
		
		for (Mobile mobile : arraylist) {
			int price=mobile.price;
			if(price>=15 && price<=30)
				treeset.add(mobile);
			}
		return treeset;*/
		
		return arraylist;

}
}
